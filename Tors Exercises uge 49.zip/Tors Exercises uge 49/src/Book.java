import java.util.Objects;

public class Book {

    private int ISBNnumber;
    private String title;
    private int published;

    public Book(int ISBNnumber, String title, int published) {
        this.ISBNnumber = ISBNnumber;
        this.title = title;
        this.published = published;
    }

    @Override
    public int hashCode() {
        return Objects.hash(ISBNnumber);
    }

    @Override
    public String toString() {
        return "ISBN-number = " + ISBNnumber + "\n" +
                "Title = " + title + "\n" +
                "Published = " + published;
    }

    public int getISBNnumber() {
        return ISBNnumber;
    }

    public void setISBNnumber(int ISBNnumber) {
        this.ISBNnumber = ISBNnumber;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getPublished() {
        return published;
    }

    public void setPublished(int published) {
        this.published = published;
    }
}
