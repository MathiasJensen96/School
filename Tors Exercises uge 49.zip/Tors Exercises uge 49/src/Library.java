import java.util.ArrayList;

public class Library {
    ArrayList<Book> books = new ArrayList<>();
    boolean contains;


    public void containsBook (Book book) {
        if (books.contains(book)) {
            System.out.println("The book is in the library");
            contains = true;
        } else {
            System.out.println("The book was not found...");
            contains = false;
        }
    }
}
