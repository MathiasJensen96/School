import java.util.Scanner;

public class MenuChoice {

    Scanner input = new Scanner(System.in);
    int choice;

    public void showMenu() {
        System.out.println("1. " + "\tBeregn");
        System.out.println("2. " + "\tUdskriv");
        System.out.println("3. " + "\tHjælp");
    }

    public void menuChoice() {
        choice = input.nextInt();
        if (choice > 0 && choice < 3) {
        switch (choice) {

                case 1:
                    System.out.println("You chose: " + choice + " = Beregn");
                    break;
                case 2:
                    System.out.println("You chose: " + choice + " = Udskriv");
                    break;
                case 3:
                    System.out.println("You need help...");
                    break;
            }
        } else {
            System.out.println("Invalid input... Shutting down..");
        }
    }
}
