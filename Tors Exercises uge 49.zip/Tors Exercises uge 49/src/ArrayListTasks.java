import java.util.ArrayList;

public class ArrayListTasks {

    private ArrayList<String> list;
    private String input;

    public ArrayListTasks(ArrayList<String> list, String input) {
        this.list = list;
        this.input = input;
    }

    public ArrayList<String> getList() {
        return list;
    }

    public String getInput() {
        return input;
    }

    public void addToList(ArrayList<String> list, String input) {
        boolean wasAdded;
        try {
            if (!list.contains(input)) {
                list.add(input);
                wasAdded = true;
            } else {
                System.out.println(input + " is already in the list");
                wasAdded = false;
            }

        } catch (NullPointerException e) {
            System.out.println("NullPointerException caught");
        }

    }
}
