public class Square {

    public void square(int i, char t) {
        if (i < 0 || i > 10) {
            System.out.println("IndexOutOfBounds - has to be between 1 and 10 positiv..");
        } else {
            for (int j = 0; j < i; j++) {
                for (int x = 0; x < i - 1; x++) {
                    System.out.print(t + "\t");
                }
                System.out.println(t);
            }

        }
    }
}