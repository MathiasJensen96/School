import java.util.Scanner;

public class Grass {
    Scanner input = new Scanner(System.in);
    private double growth = 0.8;
    private double current;
    private double max;

    public void timeToCutTheGrass() {

        int days = 0;
        System.out.println("How high is you lawn now (CM)?");
        double current = input.nextDouble();
        System.out.println("How high is it allowed to be (CM)?");
        double max = input.nextDouble();

        if (current > max) {
            System.out.println("Time to cut the grass!");
        } else {
            while (current < max) {
                current = current + growth;
                days++;
            }
            System.out.println("You need to cut your lawn in: " + days + " day(s)");
        }
    }
}
