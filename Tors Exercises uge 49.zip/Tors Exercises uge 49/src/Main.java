public class Main {

    public static void main(String[] args) {
//        ArrayList<String> list = new ArrayList<>();
//        String ptr = null;
//        ArrayListTasks taskOne = new ArrayListTasks(list, ptr);
//        taskOne.addToList(list,taskOne.getInput());
//        System.out.println(taskOne.getInput());

//        Book book1 = new Book(123, "Jaan's Xmas", 2020);
//        Library library = new Library();
//        library.books.add(book1);
//        library.containsBook(book1);

//        Grass grass = new Grass();
//        grass.timeToCutTheGrass();

//        Square square = new Square();
//        square.square(5, '%');

        MenuChoice menuChoice = new MenuChoice();
        menuChoice.showMenu();
        menuChoice.menuChoice();
    }
}
