import org.junit.jupiter.api.Test;

import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.*;

class ArrayListTasksTest {

    @Test
    void getList() {
        ArrayList<String> test = new ArrayList<>();
        ArrayListTasks taskOne = new ArrayListTasks(test,"hai");
        assertEquals("hai", taskOne.getInput());
    }

    @Test
    void getInput() {
    }
}